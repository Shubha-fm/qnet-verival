# Final LaTeX manuscript

Compile `main.tex` with pdfLaTeX at least twice, or upload this ZIP to Overleaf and select `main.tex` as the main document. All source tables, numeric macros, and PNG figures are included. No experiment rerun is required to compile the manuscript.

The supplied PDF is compiled from `main.tex` with the portable article class. `acm_main.tex` is an optional ACM entry point requiring the official acmart distribution; that class is not bundled and this alternate entry point was not compiled in the validation environment. Use the target journal's current template requirements for submission formatting.

Experimental code, original measurements, the complete dataset, graphs, results, and provenance are at https://github.com/Shubha-fm/qnet-verival/tree/main/research. The experimental archive is pinned to commit 0dcc7877755e62a216fffb95e6bf7abedc151a2f. The archived package retains the earlier manuscript for provenance; this separate LaTeX package contains the final manuscript with the verified public repository statement.

The manuscript retains anonymous authorship. The public repository URL is included as requested. Source measurements remain credited to their original IrelandQCI researchers under CC BY 4.0. The repository's research MIT license applies to experimental code, not to the manuscript or third-party data.
