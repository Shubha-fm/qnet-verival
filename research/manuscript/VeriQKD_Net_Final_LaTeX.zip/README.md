# ACM manuscript source package

Select main.tex and compile with pdfLaTeX at least twice. All LaTeX inputs, numeric tables, PNG figures, official acmart class, original class source and license, and the compiled PDF are included. Standard fonts/packages require a complete TeX Live or Overleaf installation. No experiment rerun is needed to compile the paper.

This is the public-link version. The manuscript identifies the public repository and pinned experiment revisions. main.tex compiles this public variant; an alternate public.tex entry point is also retained.

The author block remains anonymous. This does not infer or change the human author list. See VERIFICATION.md for scope and venue-check limitations.
