# ACM manuscript source package

Select main.tex and compile with pdfLaTeX at least twice. All LaTeX inputs, numeric tables, PNG figures, official acmart class, original class source and license, and the compiled PDF are included. Standard fonts/packages require a complete TeX Live or Overleaf installation. No experiment rerun is needed to compile the paper.

This is the anonymous review source package. Public repository URLs, author-identifying revision IDs, and the public.tex variant have been omitted. The accompanying review supplementary artifact provides the experiment evidence. Public source attribution remains intact.

The author block remains anonymous. This does not infer or change the human author list. See VERIFICATION.md for scope and venue-check limitations.
